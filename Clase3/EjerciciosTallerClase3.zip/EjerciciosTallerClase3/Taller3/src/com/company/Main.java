package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner miScanner = new Scanner(System.in);
        System.out.print("Por favor ingrese el nombre del gamer 1: ");
        String gamer1 = miScanner.nextLine();
        System.out.print("Por favor ingrese el nombre del gamer 2: ");
        String gamer2 = miScanner.nextLine();
        Integer jugada1 = 0;
        Integer jugada2 = 0;
        Integer contador1 = 0;
        Integer contador2 = 0;
        Integer ganadorRonda = 0;
        String ganador = "";

        System.out.println("Bienvenido gamers " +gamer1+ " y "+gamer2);

        do {
            System.out.print("Escriba " + gamer1 + " para jugar: 1.(piedra), 2.(papel),3. (tijera), 0. (*): ");
            jugada1 = miScanner.nextInt();

            System.out.print("Escriba " + gamer2 + " para jugar: 1.(piedra), 2.(papel),3. (tijera), 0. (*): ");
            jugada2 = miScanner.nextInt();

            System.out.println("La jugada de " + gamer1 + " es: " + jugada1);
            System.out.println("La jugada de " + gamer2 + " es: " + jugada2);

            if(jugada1 != 0 && jugada2 != 0 ) {

                ganadorRonda = cualGana(jugada1, jugada2);

                if (ganadorRonda.equals(1)) {
                    contador1++;
                    System.out.println("El ganador de la ronda es " + gamer1 + " la cantidad de rondas ganadas es: " + contador1);
                } else if (ganadorRonda.equals(2)) {
                    contador2++;
                    System.out.println("El ganador de la ronda es " + gamer2 + " la cantidad de rondas ganadas es: " + contador2);
                } else {
                    System.out.println("Hay un empate");
                }
            }
        }while (jugada1 != 0 && jugada2 != 0);

        if(contador1>contador2){
            ganador = gamer1;
        }else if(contador1<contador2){
            ganador = gamer2;
        }else{
            ganador = "ambos, fue un empate";
        }

        System.out.print("Usted presionó la opción 0 (*) para salir, el ganador del juego es: "+ganador);


    }

    public static Integer cualGana(Integer jugada1, Integer jugada2){
        Integer ganador = 0;
        if (jugada1 != jugada2){
            if ((jugada1 == 1 && jugada2 ==3) || (jugada1 == 2 && jugada2 ==1) || (jugada1 == 3 && jugada2 ==2)){
                return 1;
            }else {
                return 2;
            }

        }
       return 0;
    }
}
