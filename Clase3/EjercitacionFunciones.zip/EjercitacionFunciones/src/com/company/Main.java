package com.company;

import java.sql.Array;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scannerNumero = new Scanner(System.in);
        System.out.print("Ejercicio 1. Por favor ingrese un número para evaluar si es primo: ");
        Integer numero = scannerNumero.nextInt();
        System.out.println(esPrimo(numero));

        System.out.println("Ejercicio 2. Por favor ingrese 3 números tipo Integer para hallar el máximo entre ellos (Los números deben de ser diferentes)");
        System.out.print("Por favor ingrese el número A: ");
        Integer numeroA = scannerNumero.nextInt();
        System.out.print("Por favor ingrese el número B: ");
        Integer numeroB = scannerNumero.nextInt();
        System.out.print("Por favor ingrese el número C: ");
        Integer numeroC = scannerNumero.nextInt();

        String maximo = mayorNumero(numeroA,numeroB,numeroC);
        System.out.println("El mayor número es el "+maximo);

        System.out.println("Ejercicio3. Por favor ingrese 2 cadenas de texto para comparar si son iguales (Dará como resultado true o false)");
        Scanner scannerTexto = new Scanner(System.in);
        System.out.print("Por favor ingrese el texto A: ");
        String textoA = scannerTexto.nextLine();
        System.out.print("Por favor ingrese el texto B: ");
        String textoB = scannerTexto.nextLine();
        System.out.println(cadenasDeTextoDistintas(textoA, textoB));

    }

    public static boolean esDivisible(int numero1, int numero2){
        if (numero1 % numero2 == 0){
            return true;
        }else {
            return false;
        }
    };

    public static String esPrimo(Integer numero) {
        for (int i = 2; i < numero - 1; i++) {
            if (esDivisible(numero, i)) {
                return "No es un número primo";
            };
        }
        return "Es un número primo";
    }

    public static String mayorNumero(Integer numeroA, Integer numeroB, Integer numeroC){
        if(numeroA.compareTo(numeroB)>0){
            if (numeroA.compareTo(numeroC)>0){
                return "numero A";
            }
        }else{
            if (numeroB.compareTo(numeroC)>0){
                return "numero B";
            }
        }
        return "numero C";
    }

    public static boolean cadenasDeTextoDistintas(String unTextoA, String unTextoB){
        if (unTextoA.equals(unTextoB)){
            return true;
        }
        return false;
    }


}
