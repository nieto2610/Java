package com.company;

import java.util.Scanner;

public class Main {

    /*
    * Desafío 3
    Implementar un programa que nos permite mostrar por consola los primeros “n” números
    primeros, siendo “n” un valor numérico ingresado por consola. Por ejemplo: Con n=7, lo
    que debería devolver el programa es “Los primeros 7 números primos son: 2, 3, 5, 7, 11, 13,
    17”.
    * */

    public static void main(String[] args) {
        System.out.print("Por favor ingrese la cantidad de número primos que desea hallar: ");
        Scanner miScanner = new Scanner(System.in);
        Integer cantidadPrimos = miScanner.nextInt();
        cantidadNumerosPrimos(cantidadPrimos);

    }

    public static void cantidadNumerosPrimos(Integer cantidad){
        Integer numeroAEvaluar = 2;
        Boolean esPrimo = false;
        System.out.println("Los primeros "+cantidad+" números primos son: ");
        while (cantidad > 0){
            esPrimo = numeroPrimo(numeroAEvaluar);
            if (esPrimo){
                System.out.print(numeroAEvaluar + ", ");
                cantidad --;
            }
            numeroAEvaluar ++;
        }
    }

    public static boolean numeroPrimo(Integer numero){
        boolean esDivisible = true;
        for (int i=2; i<numero-1; i++){
            if(numero % i == 0){
                esDivisible = false;
            }
        }
        return esDivisible;
    }
}
