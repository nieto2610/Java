package com.company;

public class PacienteExcepcion extends RuntimeException{
    public PacienteExcepcion(){
        super();
    }
    public PacienteExcepcion(String mensaje){
        super(mensaje);
    }
    @Override
    public String toString(){
        return "Se produjo la siguiente Excepcion: " + this.getClass().getName()+ '\n'+
                "Mensaje: "+this.getMessage()+'\n';
    }
}
