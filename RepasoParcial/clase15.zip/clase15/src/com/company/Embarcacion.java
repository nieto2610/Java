package com.company;

public abstract class Embarcacion {

    private Capitan capitan;
    private Double precioBase;
    private Double valorAdicional;
    private Integer anioFabricación;
    private Double eslora;

    public Embarcacion(Capitan capitan, Double precioBase, Double valorAdicional, Integer anioFabricación, Double eslora) {
        this.capitan = capitan;
        this.precioBase = precioBase;
        this.valorAdicional = valorAdicional;
        this.anioFabricación = anioFabricación;
        this.eslora = eslora;
    }
     public Double calcularMontoAlquiler (){
        Double montoAlquiler=precioBase;
        if (anioFabricación>2020){
            montoAlquiler+=valorAdicional;
        }
        return montoAlquiler;
     }

}
