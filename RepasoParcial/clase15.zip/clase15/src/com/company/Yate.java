package com.company;

public class Yate extends Embarcacion implements Comparable{

    private int cantidadCamarotes;

    public Yate(Capitan capitan, Double precioBase, Double valorAdicional, Integer anioFabricación, Double eslora, int cantidadCamarotes) {
        super(capitan, precioBase, valorAdicional, anioFabricación, eslora);
        this.cantidadCamarotes = cantidadCamarotes;
    }

    @Override
    public int compareTo(Object object){
        Yate otroYate=(Yate)object;
        return (cantidadCamarotes-otroYate.cantidadCamarotes);
    }

}
/*compareTo  si Y1>Y2 -> mayor que cero
           si Y2>Y1 -> menor que cero
           si Y1=Y2 -> 0
*/