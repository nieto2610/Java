package com.company;

public class Main {

    public static void main(String[] args) {
	 Capitan unCapitan= new Capitan("Mauricio","Grisales","POO002");
        //System.out.println(unCapitan.toString());
        System.out.println("El nombre del capitán es: "+ unCapitan.getNombre());
        System.out.println("El apellido del capitán es: "+ unCapitan.getApellido());
        System.out.println("La matrícula del capitán es: "+ unCapitan.getMatricula());
        Yate unYate= new Yate(unCapitan,25000.50,2500.25,2021,22.3,10 );
        Yate otroYate= new Yate(unCapitan,15000.50,2500.25,2010,15.3,6 );
        if(unYate.compareTo(otroYate)>0){
            System.out.println("El primer yate tiene más camarotes que el segundo");
        } else if(unYate.compareTo(otroYate)<0){
            System.out.println("El segundo yate tiene más camarotes que el primero");
        }else{
            System.out.println("Ambos yates tienen el mismo número de camarotes");
        }
        System.out.println("El alquiler del primer yate es: "+unYate.calcularMontoAlquiler());
        System.out.println("El alquiler del segundo yate es: "+otroYate.calcularMontoAlquiler());

        Velero unVelero= new Velero(unCapitan,10000.50,2500.25,2021,22.3,6 );
        System.out.println("¿El velero es grande?: "+ unVelero.esGrande());
        System.out.println("El alquiler del velero es: "+ unVelero.calcularMontoAlquiler());
    }

}
//https://drive.google.com/file/d/1IzOd2EwrWfRFBawTfZDjrBvNmi_LskNk/view?usp=sharing