package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

	    Scanner miScannerPG = new Scanner(System.in);

        System.out.print("Ingrese su nombre: ");
        String unNombre = miScannerPG.nextLine();

        System.out.print("Ingrese su apellido: ");
        String unApellido = miScannerPG.nextLine();

        System.out.println("Mi nombre es " +unNombre+ " "+unApellido);

        Character inicialNombre = unNombre.charAt(0);
        Character iniciaApellido = unApellido.charAt(0);

        String unasIniciales = new StringBuilder().append(inicialNombre).append(iniciaApellido).toString();


        System.out.println("Mis iniciales son "+unasIniciales);

        System.out.print("Ingrese su día de nacimiento: ");
        Integer unDia = miScannerPG.nextInt();
        System.out.print("Ingrese su mes de nacimiento: ");
        Integer unMes = miScannerPG.nextInt();
        System.out.print("Ingrese su año de nacimiento: ");
        Integer unAño = miScannerPG.nextInt();

        System.out.print("Mi Fecha de nacimiento es: "+fechaCompleta(unDia, unMes, unAño));


    }

    public static String fechaCompleta(Integer dia, Integer mes, Integer año){
        return dia+"/"+mes+"/"+año;
    }
}
